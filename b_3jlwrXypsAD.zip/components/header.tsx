"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="w-full">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground py-2">
        <div className="container mx-auto px-4 flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span>Soluciones Forestales y Ambientales</span>
            </div>
            <div className="hidden md:flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <span>info@tamefor.com</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2">
              <Phone className="h-4 w-4" />
              <span>+52 123 456 7890</span>
            </div>
            <div className="flex items-center gap-3">
              <Link href="#" className="hover:opacity-80 transition-opacity"><Facebook className="h-4 w-4" /></Link>
              <Link href="#" className="hover:opacity-80 transition-opacity"><Twitter className="h-4 w-4" /></Link>
              <Link href="#" className="hover:opacity-80 transition-opacity"><Instagram className="h-4 w-4" /></Link>
              <Link href="#" className="hover:opacity-80 transition-opacity"><Linkedin className="h-4 w-4" /></Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="bg-card shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-3">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5K5il-aXvgEgMRMsZLVxpjVmIlhZEkfwsKOQ.jpg" 
              alt="TAMEFOR Logo"
              className="h-12 w-auto"
            />
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center gap-8">
            <Link href="#" className="text-foreground hover:text-primary transition-colors font-medium">Home</Link>
            <Link href="#about" className="text-foreground hover:text-primary transition-colors font-medium">About</Link>
            <Link href="#services" className="text-foreground hover:text-primary transition-colors font-medium">Services</Link>
            <Link href="#campaigns" className="text-foreground hover:text-primary transition-colors font-medium">Campaigns</Link>
            <Link href="#projects" className="text-foreground hover:text-primary transition-colors font-medium">Projects</Link>
            <Link href="#events" className="text-foreground hover:text-primary transition-colors font-medium">Events</Link>
            <Link href="#blog" className="text-foreground hover:text-primary transition-colors font-medium">Blog</Link>
          </div>

          <div className="hidden lg:flex items-center gap-4">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-6">
              Donate Now
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-card border-t mt-4 py-4">
            <div className="container mx-auto px-4 flex flex-col gap-4">
              <Link href="#" className="text-foreground hover:text-primary transition-colors font-medium py-2">Home</Link>
              <Link href="#about" className="text-foreground hover:text-primary transition-colors font-medium py-2">About</Link>
              <Link href="#services" className="text-foreground hover:text-primary transition-colors font-medium py-2">Services</Link>
              <Link href="#campaigns" className="text-foreground hover:text-primary transition-colors font-medium py-2">Campaigns</Link>
              <Link href="#projects" className="text-foreground hover:text-primary transition-colors font-medium py-2">Projects</Link>
              <Link href="#events" className="text-foreground hover:text-primary transition-colors font-medium py-2">Events</Link>
              <Link href="#blog" className="text-foreground hover:text-primary transition-colors font-medium py-2">Blog</Link>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full w-full mt-2">
                Donate Now
              </Button>
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
