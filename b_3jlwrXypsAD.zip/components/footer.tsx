"use client"

import Link from "next/link"
import { MapPin, Mail, Phone, Facebook, Twitter, Instagram, Linkedin, ArrowRight, Send } from "lucide-react"
import Image from "next/image"

const quickLinks = [
  { label: "Sobre la Empresa", href: "#about" },
  { label: "Nuestras Causas", href: "#campaigns" },
  { label: "Presentación", href: "#" },
  { label: "Plan de Precios", href: "#" },
  { label: "Conoce al Equipo", href: "#" },
  { label: "Contáctanos", href: "#contact" },
]

const services = [
  { label: "Plantación de Árboles", href: "#" },
  { label: "Limpieza Forestal", href: "#" },
  { label: "Reciclaje de Plásticos", href: "#" },
  { label: "Energía Natural", href: "#" },
  { label: "Energía Renovable", href: "#" },
  { label: "Purificación de Agua", href: "#" },
]

export function Footer() {
  return (
    <footer className="bg-[#1a3a5c] text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Link href="/" className="inline-block mb-6">
              <Image 
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5K5il-aXvgEgMRMsZLVxpjVmIlhZEkfwsKOQ.jpg" 
                alt="TAMEFOR Logo"
                width={140}
                height={56}
                className="bg-white/90 rounded-lg p-2"
              />
            </Link>
            <p className="text-white/70 mb-6 leading-relaxed">
              Presentamos a nuestro equipo de profesionales talentosos y capacitados que están listos para aumentar tu productividad y hacer crecer tu negocio.
            </p>
            <div className="mb-4">
              <p className="font-bold text-white">¡Estamos Disponibles!</p>
              <p className="text-white/70">Lun-Sáb: <span className="text-[#d4a853]">10:00am a 07:30pm</span></p>
            </div>
            <div className="flex gap-3">
              <Link href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#3d9a8b] transition-colors">
                <Facebook className="h-4 w-4" />
              </Link>
              <Link href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#3d9a8b] transition-colors">
                <Twitter className="h-4 w-4" />
              </Link>
              <Link href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#3d9a8b] transition-colors">
                <Instagram className="h-4 w-4" />
              </Link>
              <Link href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#3d9a8b] transition-colors">
                <Linkedin className="h-4 w-4" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <svg className="w-5 h-5 text-[#d4a853]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <h3 className="font-serif text-xl font-bold">Enlaces Rápidos</h3>
            </div>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <Link href={link.href} className="text-white/70 hover:text-[#d4a853] transition-colors flex items-center gap-2 group">
                    <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity text-[#d4a853]" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <svg className="w-5 h-5 text-[#d4a853]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <h3 className="font-serif text-xl font-bold">Nuestros Servicios</h3>
            </div>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <Link href={service.href} className="text-white/70 hover:text-[#d4a853] transition-colors flex items-center gap-2 group">
                    <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity text-[#d4a853]" />
                    {service.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <svg className="w-5 h-5 text-[#d4a853]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <h3 className="font-serif text-xl font-bold">Contacto</h3>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-5 w-5 text-[#1a3a5c]" />
                </div>
                <div>
                  <p className="font-semibold">Dirección</p>
                  <p className="text-white/70">Ciudad de México, México</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                  <Send className="h-5 w-5 text-[#1a3a5c]" />
                </div>
                <div>
                  <p className="font-semibold">Email</p>
                  <a href="mailto:info@tamefor.com" className="text-white/70 hover:text-[#d4a853] transition-colors">
                    info@tamefor.com
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                  <Phone className="h-5 w-5 text-[#1a3a5c]" />
                </div>
                <div>
                  <p className="font-semibold">Teléfono</p>
                  <a href="tel:+521234567890" className="text-white/70 hover:text-[#d4a853] transition-colors">
                    +52 123 456 7890
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-[#3d9a8b] py-4">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white text-sm">
            © 2026 TAMEFOR. Todos los derechos reservados.
          </p>
          <div className="flex gap-6 text-sm text-white">
            <Link href="#" className="hover:text-[#d4a853] transition-colors">Términos y Condiciones</Link>
            <span className="text-white/40">•</span>
            <Link href="#" className="hover:text-[#d4a853] transition-colors">Política de Privacidad</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
