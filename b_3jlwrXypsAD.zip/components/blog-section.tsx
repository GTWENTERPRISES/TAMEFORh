"use client"

import { ArrowRight, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const posts = [
  {
    date: "09",
    month: "Ene",
    year: "2026",
    category: "Bosque",
    title: "Gestión de Residuos",
    excerpt: "Consultoría ambiental que incluye asesoramiento y orientación en energía",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=2071",
    shares: 367,
  },
  {
    date: "24",
    month: "Feb",
    year: "2026",
    category: "Reciclaje",
    title: "Gestión de Residuos",
    excerpt: "Consultoría ambiental que incluye asesoramiento y orientación en energía",
    image: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?q=80&w=2070",
    shares: 367,
  },
  {
    date: "15",
    month: "Mar",
    year: "2026",
    category: "Bosque",
    title: "Gestión de Residuos",
    excerpt: "Consultoría ambiental que incluye asesoramiento y orientación en energía",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070",
    shares: 367,
  },
]

export function BlogSection() {
  return (
    <section id="blog" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Left Side - Header */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-[#3d9a8b]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-[#3d9a8b] font-medium">Noticias y Blog</span>
            </div>
            
            <h2 className="font-serif text-4xl text-[#1a3a5c] leading-tight mb-6">
              Últimas Publicaciones del Blog
            </h2>
            
            <p className="text-muted-foreground mb-8">
              Cámaras avanzadas combinadas con gran pantalla, rendimiento rápido y alta calidad.
            </p>

            <Button className="bg-[#1a3a5c] hover:bg-[#0f2a45] text-white rounded-full px-6">
              Explorar Todo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>

          {/* Right Side - Blog Cards */}
          <div className="lg:col-span-3 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post, index) => (
              <div
                key={index}
                className="group bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-border"
              >
                {/* Image */}
                <div className="relative overflow-hidden h-56">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Category Badge */}
                  <div className="absolute top-4 left-4 bg-[#1a3a5c] text-white px-4 py-1 rounded-full text-sm">
                    {post.category}
                  </div>
                  {/* Date Badge */}
                  <div className="absolute bottom-4 right-4 bg-[#3d9a8b] rounded-xl p-3 text-center">
                    <div className="text-2xl font-bold text-white">{post.date}</div>
                    <div className="text-xs text-white/80">{post.month}</div>
                    <div className="text-xs text-white/60 border-t border-white/20 pt-1 mt-1">{post.year}</div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="font-serif text-xl font-bold text-[#1a3a5c] mb-3 group-hover:text-[#3d9a8b] transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 text-sm">{post.excerpt}</p>
                  
                  <div className="flex items-center justify-between">
                    <Button variant="outline" size="sm" className="rounded-full border-[#1a3a5c] text-[#1a3a5c] hover:bg-[#1a3a5c] hover:text-white">
                      Leer Más
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                    <div className="flex items-center gap-2 text-muted-foreground text-sm">
                      <Share2 className="w-4 h-4" />
                      <span>{post.shares}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
