"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"
import Image from "next/image"

const slides = [
  {
    subtitle: "Salvemos el Medio Ambiente",
    title: "Transforma el Mundo",
    titleHighlight: "Con el Corazón",
    description: "Trabajamos para proteger y restaurar el medio ambiente natural.",
  },
  {
    subtitle: "Actuemos por el Futuro",
    title: "Construyamos la Tierra",
    titleHighlight: "Con Visión Verde",
    description: "Una semilla plantada con cuidado crece hasta convertirse en un bosque que protege la vida.",
  },
]

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2013"
          alt="Volunteers planting trees"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a3a5c]/95 via-[#1a3a5c]/70 to-transparent" />
      </div>

      {/* Social Links - Right Side */}
      <div className="absolute right-8 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-4 z-20">
        <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-[#3d9a8b] transition-colors cursor-pointer">
          <Facebook className="w-4 h-4 text-white" />
        </div>
        <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-[#3d9a8b] transition-colors cursor-pointer">
          <Twitter className="w-4 h-4 text-white" />
        </div>
        <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-[#3d9a8b] transition-colors cursor-pointer">
          <Instagram className="w-4 h-4 text-white" />
        </div>
        <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-[#3d9a8b] transition-colors cursor-pointer">
          <Linkedin className="w-4 h-4 text-white" />
        </div>
        <div className="writing-mode-vertical text-white/60 text-sm mt-4 rotate-180" style={{ writingMode: 'vertical-rl' }}>
          Únete Social
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          {/* Badge */}
          <div className="flex items-center gap-2 mb-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2">
              <svg className="w-5 h-5 text-[#d4a853]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-white/90 text-sm">{slides[currentSlide].subtitle}</span>
            </div>
          </div>

          {/* Slide Content */}
          <div className="space-y-6">
            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl text-white font-bold leading-tight">
              {slides[currentSlide].title}<br />
              <span className="text-[#d4a853]">{slides[currentSlide].titleHighlight}</span>
            </h1>
            <p className="text-white/80 text-lg max-w-xl">
              {slides[currentSlide].description}
            </p>

            <div className="flex flex-wrap items-center gap-6 pt-4">
              <Button size="lg" className="bg-[#d4a853] hover:bg-[#c49843] text-[#1a3a5c] rounded-full px-8 group font-semibold">
                Únete Hoy
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              {/* Team Avatars */}
              <div className="flex items-center gap-4">
                <div className="flex -space-x-3">
                  <div className="w-12 h-12 rounded-full border-2 border-white overflow-hidden">
                    <Image src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100" alt="Team member" width={48} height={48} className="object-cover" />
                  </div>
                  <div className="w-12 h-12 rounded-full border-2 border-white overflow-hidden">
                    <Image src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=100" alt="Team member" width={48} height={48} className="object-cover" />
                  </div>
                  <div className="w-12 h-12 rounded-full border-2 border-white bg-[#d4a853] flex items-center justify-center text-[#1a3a5c] font-bold text-sm">
                    +5
                  </div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">122.6k+</div>
                  <div className="text-white/60 text-sm">Miembros del Equipo</div>
                </div>
              </div>
            </div>
          </div>

          {/* Slide Indicators */}
          <div className="flex gap-2 mt-12">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-3 rounded-full transition-all ${
                  currentSlide === index ? "w-8 bg-white" : "w-3 bg-white/40"
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Decorative wave at bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V120Z" fill="white" fillOpacity="0.1"/>
        </svg>
      </div>
    </section>
  )
}
