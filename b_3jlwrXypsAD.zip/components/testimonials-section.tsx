"use client"

import { Star, Play, ArrowRight, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Content */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-[#3d9a8b]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-[#3d9a8b] font-medium">Testimonios</span>
            </div>
            
            <h2 className="font-serif text-4xl md:text-5xl text-[#1a3a5c] leading-tight mb-2">
              Por Qué Confían
            </h2>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-[#d4a853] rounded-full flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-[#1a3a5c]" />
              </div>
              <span className="font-serif text-4xl md:text-5xl text-[#1a3a5c]">En Nosotros</span>
            </div>
            
            <p className="text-muted-foreground mb-8 max-w-md">
              Nuestros clientes están altamente satisfechos y recomiendan nuestros servicios.
            </p>

            {/* Stats */}
            <div className="flex items-center gap-4 mb-8">
              <div className="text-5xl font-serif font-bold text-[#1a3a5c]">99%</div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-[#3d9a8b] rounded-full flex items-center justify-center">
                  <Check className="w-5 h-5 text-white" />
                </div>
                <span className="text-[#1a3a5c] font-semibold">Reseñas Positivas</span>
              </div>
            </div>

            {/* Write Review CTA */}
            <div className="bg-muted rounded-2xl p-4 inline-flex items-center gap-3">
              <div className="w-12 h-12 bg-[#d4a853] rounded-full flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-[#1a3a5c]" />
              </div>
              <div>
                <p className="text-[#3d9a8b] font-medium">Escribe tu reseña</p>
                <p className="text-muted-foreground text-sm flex items-center gap-1">
                  honesta <ArrowRight className="w-3 h-3" />
                </p>
              </div>
            </div>
          </div>

          {/* Right Side - Video Testimonial */}
          <div className="relative">
            {/* Main Image */}
            <div className="relative rounded-2xl overflow-hidden h-[400px]">
              <Image
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1888"
                alt="Testimonio en video"
                fill
                className="object-cover"
              />
              {/* Play Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-xl">
                  <Play className="w-8 h-8 text-[#1a3a5c] fill-current ml-1" />
                </button>
              </div>
            </div>

            {/* Testimonial Card */}
            <div className="absolute -bottom-6 -right-6 bg-[#1a3a5c] rounded-2xl p-6 max-w-xs shadow-xl">
              {/* Rating Badge */}
              <div className="bg-[#d4a853] rounded-full px-3 py-1 inline-flex items-center gap-1 mb-4">
                <span className="text-[#1a3a5c] text-sm font-medium">Rating</span>
                <Star className="w-4 h-4 text-[#1a3a5c] fill-current" />
                <span className="text-[#1a3a5c] font-bold">5.0</span>
              </div>
              
              <p className="text-white/90 text-sm mb-4 leading-relaxed">
                Quedé muy impresionado - proporcionaron excelente asesoramiento y orientación.
              </p>
              
              <div>
                <p className="text-white font-semibold">Penélope Miller <span className="text-white/60 font-normal">(Arjun)</span></p>
                <p className="text-white/60 text-sm">Voluntaria Sr.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function Check({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
      <polyline points="20,6 9,17 4,12" />
    </svg>
  )
}
