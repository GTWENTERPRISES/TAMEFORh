"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const projects = [
  {
    number: "01",
    title: "Gestión de Residuos",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en gestión de residuos",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2032",
    category: "Reciclaje"
  },
  {
    number: "02",
    title: "Gestión Forestal",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en conservación forestal",
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2013",
    category: "Bosque"
  },
  {
    number: "03",
    title: "Limpieza de Bosques",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en limpieza forestal",
    image: "https://images.unsplash.com/photo-1559827291-72ee739d0d9a?q=80&w=2074",
    category: "Limpieza"
  },
  {
    number: "04",
    title: "Reforestación",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en plantación de árboles",
    image: "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?q=80&w=2088",
    category: "Plantación"
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-20 bg-[#1a3a5c] relative overflow-hidden">
      {/* Decorative leaf pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <pattern id="leaves" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M10 0C15 5 15 15 10 20C5 15 5 5 10 0Z" fill="currentColor" />
          </pattern>
          <rect width="100" height="100" fill="url(#leaves)" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-[#3d9a8b]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-[#3d9a8b] font-medium">Proyectos Completados</span>
            </div>
            <h2 className="font-serif text-4xl md:text-5xl text-white leading-tight">
              Explora Nuestros Proyectos<br />Exitosos
            </h2>
          </div>
          <div className="mt-6 lg:mt-0">
            <Button className="bg-transparent border-2 border-[#d4a853] text-[#d4a853] hover:bg-[#d4a853] hover:text-[#1a3a5c] rounded-full px-6">
              Ver Todos los Proyectos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project) => (
            <div 
              key={project.number}
              className="group relative"
            >
              {/* Number Badge */}
              <div className="absolute -top-3 right-6 z-20 bg-[#d4a853]/20 backdrop-blur-sm rounded-full px-3 py-1 text-white text-sm border border-[#d4a853]/30">
                No - {project.number}
              </div>
              
              {/* Image Container */}
              <div className="relative h-[350px] rounded-2xl overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a3a5c]/95 via-[#1a3a5c]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Content on Hover */}
                <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <div className="bg-white/95 backdrop-blur-sm rounded-xl p-4">
                    <h3 className="font-serif text-lg text-[#1a3a5c] mb-2">{project.title}</h3>
                    <p className="text-[#1a3a5c]/70 text-sm mb-3">{project.description}</p>
                    <Button variant="outline" size="sm" className="border-[#3d9a8b] text-[#3d9a8b] hover:bg-[#3d9a8b] hover:text-white rounded-full">
                      Ver Proyecto
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                  </div>
                </div>

                {/* Category Badge */}
                <div className="absolute bottom-4 right-4 bg-[#1a3a5c] rounded-full px-4 py-1 text-white text-sm group-hover:opacity-0 transition-opacity">
                  {project.category}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
