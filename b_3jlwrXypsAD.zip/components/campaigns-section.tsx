"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Heart, Calendar } from "lucide-react"
import Image from "next/image"

const campaigns = [
  {
    image: "https://images.unsplash.com/photo-1474511320723-9a56873571b7?q=80&w=2072",
    category: "Animal",
    title: "Energía Sostenible para Todos: Por Qué Tu Donación Importa",
    description: "Trabajamos para proteger y restaurar el medio ambiente natural.",
    progress: 72,
    raised: "$9,650",
    goal: "$16,560",
    daysLeft: 29,
    likes: 259,
  },
  {
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2013",
    category: "Plantación",
    title: "Campaña de Reforestación y Plantación de Árboles 2026",
    description: "Trabajamos para proteger y restaurar el medio ambiente natural.",
    progress: 64,
    raised: "$6,650",
    goal: "$10,560",
    daysLeft: 29,
    likes: 259,
  },
  {
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070",
    category: "Animal",
    title: "Protegiendo Especies en Peligro y Sus Hábitats",
    description: "Trabajamos para proteger y restaurar el medio ambiente natural.",
    progress: 89,
    raised: "$13,650",
    goal: "$16,560",
    daysLeft: 29,
    likes: 259,
  },
]

export function CampaignsSection() {
  return (
    <section id="campaigns" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <svg className="w-5 h-5 text-[#3d9a8b]" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
            </svg>
            <span className="text-[#3d9a8b] font-medium">Nuestras Campañas</span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl text-[#1a3a5c] leading-tight">
            Tu Regalo Para un Mañana Más Verde
          </h2>
        </div>

        {/* Campaign Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {campaigns.map((campaign, index) => (
            <div
              key={index}
              className="group bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-border"
            >
              {/* Image */}
              <div className="relative overflow-hidden h-56">
                <Image
                  src={campaign.image}
                  alt={campaign.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {/* Category Badge */}
                <div className="absolute top-4 left-4 bg-[#1a3a5c] text-white px-4 py-1 rounded-full text-sm font-medium">
                  {campaign.category}
                </div>
                {/* Days Left Badge */}
                <div className="absolute bottom-4 left-4 bg-white rounded-full px-3 py-1 flex items-center gap-2 text-sm shadow-lg">
                  <Calendar className="w-4 h-4 text-[#1a3a5c]" />
                  <span className="text-[#1a3a5c]">{campaign.daysLeft} Días Restantes</span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="font-serif text-xl font-bold text-[#1a3a5c] mb-3 line-clamp-2">{campaign.title}</h3>
                <p className="text-muted-foreground mb-4">{campaign.description}</p>
                
                {/* Progress */}
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-[#1a3a5c] font-medium">Donación Completa</span>
                    <span className="text-[#3d9a8b] font-bold">{campaign.progress}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-[#3d9a8b] rounded-full transition-all duration-500"
                      style={{ width: `${campaign.progress}%` }}
                    />
                  </div>
                </div>
                
                {/* Raised/Goal */}
                <div className="flex justify-between text-sm mb-6">
                  <div>
                    <span className="text-muted-foreground">Recaudado: </span>
                    <span className="font-bold text-[#3d9a8b]">{campaign.raised}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Meta: </span>
                    <span className="font-bold text-[#1a3a5c]">{campaign.goal}</span>
                  </div>
                </div>

                {/* CTA */}
                <div className="flex items-center justify-between">
                  <Button className="bg-[#d4a853] hover:bg-[#c49843] text-[#1a3a5c] rounded-full px-5 font-semibold">
                    Donar Ahora
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Heart className="w-4 h-4" />
                    <span className="text-sm">{campaign.likes}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
