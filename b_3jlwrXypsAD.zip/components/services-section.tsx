"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const services = [
  {
    number: "01",
    title: "Gestión de Residuos",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en gestión de residuos",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070"
  },
  {
    number: "02",
    title: "Limpieza de Océanos",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en conservación marina",
    image: "https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?q=80&w=2070"
  },
  {
    number: "03",
    title: "Reciclaje de Plásticos",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en reciclaje",
    image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?q=80&w=2070"
  },
  {
    number: "04",
    title: "Plantación de Árboles",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en reforestación",
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2013"
  },
  {
    number: "05",
    title: "Restauración Ecológica",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en ecosistemas",
    image: "https://images.unsplash.com/photo-1569880153113-76e33fc52d5f?q=80&w=2070"
  },
  {
    number: "06",
    title: "Auditorías Verdes",
    description: "Consultoría ambiental que incluye asesoramiento y orientación en energía verde",
    image: "https://images.unsplash.com/photo-1473445730015-841f29a9490b?q=80&w=2070"
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-[#1a3a5c]">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-[#d4a853]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-[#d4a853] font-medium">Qué Hacemos</span>
            </div>
            <h2 className="font-serif text-4xl md:text-5xl text-white leading-tight">
              Ofrecemos Diferentes<br />Servicios Para Ayudarte
            </h2>
          </div>
          <div className="mt-6 lg:mt-0 lg:text-right">
            <p className="text-white/80 mb-4 max-w-sm">
              Soluciones avanzadas, alto rendimiento y máxima calidad.
            </p>
            <Button variant="link" className="text-[#d4a853] p-0 hover:text-[#e5b964]">
              Ver Todos los Servicios <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div 
              key={service.number}
              className="group relative h-[400px] rounded-2xl overflow-hidden cursor-pointer"
            >
              {/* Background Image */}
              <Image
                src={service.image}
                alt={service.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-110"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#1a3a5c]/90 via-[#1a3a5c]/40 to-transparent" />
              
              {/* Number Badge */}
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1 text-white text-sm">
                No - {service.number}
              </div>
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="bg-[#1a3a5c]/80 backdrop-blur-sm rounded-xl p-4">
                  <h3 className="font-serif text-xl text-white mb-2">{service.title}</h3>
                  <p className="text-white/70 text-sm">{service.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
