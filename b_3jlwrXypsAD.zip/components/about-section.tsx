"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Check, ArrowRight, Play, TrendingUp, Lightbulb, ThumbsUp, Users } from "lucide-react"
import Image from "next/image"

const tabs = ["Nuestra Historia", "Nuestra Misión", "Nuestra Visión"]

const tabContent = {
  "Nuestra Historia": {
    text: "Trabajamos para proteger y restaurar el medio ambiente natural a través de décadas de dedicación y compromiso con la preservación ecológica.",
    points: [
      "Naturaleza ecológicamente aceptable, organismos y ambiente",
      "Ecología es el estudio de la relación entre los seres vivos",
      "Enfoque en tus tareas y proyectos importantes",
    ],
  },
  "Nuestra Misión": {
    text: "Trabajamos para proteger y restaurar el medio ambiente natural implementando soluciones sostenibles y participación comunitaria.",
    points: [
      "Naturaleza ecológicamente aceptable, organismos y ambiente",
      "Ecología es el estudio de la relación entre los seres vivos",
      "Enfoque en tus tareas y proyectos importantes",
    ],
  },
  "Nuestra Visión": {
    text: "Trabajamos para proteger y restaurar el medio ambiente natural para las generaciones futuras a través de innovación y colaboración global.",
    points: [
      "Naturaleza ecológicamente aceptable, organismos y ambiente",
      "Ecología es el estudio de la relación entre los seres vivos",
      "Enfoque en tus tareas y proyectos importantes",
    ],
  },
}

const stats = [
  { icon: TrendingUp, value: "41%", label: "Éxito de la Empresa" },
  { icon: Lightbulb, value: "234+", label: "Estrategias Desarrolladas" },
  { icon: ThumbsUp, value: "15k", label: "Proyectos Completados" },
  { icon: Users, value: "42+", label: "Miembros con Experiencia" },
]

export function AboutSection() {
  const [activeTab, setActiveTab] = useState("Nuestra Historia")

  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <div className="relative">
            {/* Main Image */}
            <div className="relative z-10 w-64 h-80 rounded-2xl overflow-hidden border-4 border-[#d4a853]">
              <Image
                src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?q=80&w=2074"
                alt="Voluntario ambiental"
                fill
                className="object-cover"
              />
              {/* Award Badge */}
              <div className="absolute bottom-4 left-4 right-4 bg-[#1a3a5c] rounded-xl p-3 flex items-center gap-3">
                <div className="w-10 h-10 bg-[#d4a853] rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#1a3a5c]" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white text-sm font-semibold">2024 - Somos los</p>
                  <p className="text-[#d4a853] text-xs">mejores ganadores</p>
                </div>
              </div>
            </div>

            {/* Secondary Image with Play Button */}
            <div className="absolute top-20 left-48 w-56 h-72 rounded-full overflow-hidden border-4 border-white shadow-xl z-20">
              <Image
                src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2013"
                alt="Persona con planta"
                fill
                className="object-cover"
              />
              {/* Play Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 text-[#1a3a5c] fill-current ml-1" />
                </button>
              </div>
            </div>

            {/* Years Experience Badge */}
            <div className="absolute -top-4 right-8 bg-[#d4a853] rounded-2xl p-4 z-30">
              <div className="text-4xl font-bold text-[#1a3a5c]">29<span className="text-2xl">+</span></div>
              <div className="text-[#1a3a5c] text-sm font-medium">Años de<br/>experiencia</div>
            </div>

            {/* Decorative dots */}
            <div className="absolute bottom-0 left-0 grid grid-cols-6 gap-1">
              {Array.from({ length: 18 }).map((_, i) => (
                <div key={i} className="w-2 h-2 rounded-full bg-[#3d9a8b]/30" />
              ))}
            </div>
          </div>

          {/* Content Side */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-[#3d9a8b]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C13.5 2 15 3.5 15 5C15 6.5 13.5 8 12 8C10.5 8 9 6.5 9 5C9 3.5 10.5 2 12 2ZM17 7C17 7 21 10 21 14C21 18 17 22 12 22C7 22 3 18 3 14C3 10 7 7 7 7" />
              </svg>
              <span className="text-[#3d9a8b] font-medium">Sobre Nosotros</span>
            </div>
            
            <h2 className="font-serif text-4xl md:text-5xl text-[#1a3a5c] leading-tight mb-6">
              Construyendo un Futuro<br />Más Verde Juntos
            </h2>

            {/* Tabs */}
            <div className="flex flex-wrap gap-2 mb-6">
              {tabs.map((tab) => (
                <Button
                  key={tab}
                  variant={activeTab === tab ? "default" : "outline"}
                  onClick={() => setActiveTab(tab)}
                  className={`rounded-full ${
                    activeTab === tab 
                      ? "bg-[#1a3a5c] text-white hover:bg-[#0f2a45]" 
                      : "border-[#1a3a5c] text-[#1a3a5c] hover:bg-[#1a3a5c] hover:text-white"
                  }`}
                >
                  {tab}
                </Button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="space-y-4 mb-8">
              <p className="text-muted-foreground leading-relaxed">
                {tabContent[activeTab as keyof typeof tabContent].text}
              </p>
              <ul className="space-y-3">
                {tabContent[activeTab as keyof typeof tabContent].points.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="bg-[#3d9a8b]/10 rounded-full p-1 mt-0.5">
                      <Check className="h-4 w-4 text-[#3d9a8b]" />
                    </div>
                    <span className="text-foreground">{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA and Trustpilot */}
            <div className="flex flex-wrap items-center gap-6">
              <Button className="bg-[#1a3a5c] hover:bg-[#0f2a45] text-white rounded-full px-6 group">
                Explorar Más
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <div className="flex items-center gap-2">
                <span className="text-[#1a3a5c] font-semibold">Trustpilot</span>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-5 h-5 bg-[#00b67a]">
                      <svg viewBox="0 0 20 20" fill="white" className="w-full h-full p-0.5">
                        <path d="M10 1L12.39 6.86H18.66L13.63 10.64L15.52 16.5L10 12.72L4.48 16.5L6.37 10.64L1.34 6.86H7.61L10 1Z" />
                      </svg>
                    </div>
                  ))}
                </div>
                <span className="text-muted-foreground text-sm">Excelente 4.9 de 5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 pt-12 border-t border-border">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full border-2 border-[#d4a853]/30 flex items-center justify-center">
                <stat.icon className="w-7 h-7 text-[#d4a853]" />
              </div>
              <div className="text-4xl md:text-5xl font-serif font-bold text-[#1a3a5c] mb-2">{stat.value}</div>
              <div className="text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
