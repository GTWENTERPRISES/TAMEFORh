import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ServicesSection } from "@/components/services-section"
import { WhyChooseSection } from "@/components/why-choose-section"
import { CampaignsSection } from "@/components/campaigns-section"
import { VolunteerBanner } from "@/components/volunteer-banner"
import { ProjectsSection } from "@/components/projects-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { PartnersSection } from "@/components/partners-section"
import { DonateSection } from "@/components/donate-section"
import { EventsSection } from "@/components/events-section"
import { BlogSection } from "@/components/blog-section"
import { NewsletterSection } from "@/components/newsletter-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <WhyChooseSection />
      <CampaignsSection />
      <VolunteerBanner />
      <ProjectsSection />
      <TestimonialsSection />
      <PartnersSection />
      <DonateSection />
      <EventsSection />
      <BlogSection />
      <NewsletterSection />
      <Footer />
    </main>
  )
}
